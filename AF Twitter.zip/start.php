<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
define("CONSUMER_KEY", "I5i K0n5Um3r k3Y mV m0"); #Consumer Keymu
define("CONSUMER_SECRET", "15i k0nsuM3r 53cR3t mV m0"); #Consumer Secret Kamu
define("OAUTH_CALLBACK", "http://websitemu.com/callback.php"); #Edit tulisan websitemu.com
$db_host	=	"Localhost"; 	#Diisi nama host, default localhost
$db_user	=	"root";		#Diisi username database, default root
$db_name	=	"tukang";	#Diisi nama databasemu
$db_pass	=	"anjing"; #Password database
$site		=	"Situs Autofollow"; #Title Websitemu
$admin		=	"Dh1ki"; #Nama mu
$idadmin	=	"948727974"; #Id twittermu
$text 		= 	"Ay0 p4K3 4ut0 foLL0W Bv4t4N m3mb3R JKT CYBER TEAM"; #Teks Promosi
$link 		= 	"http://webmu.com/callback.php"; #link webmu apakek namanya, buat promosi, kalo bisa pake shorten link, jangan adf.ly
$connect	=mysql_connect($db_host,$db_user,$db_pass);
$cekdb		=mysql_select_db($db_name,$connect);
?>