<?php include ('../html.inc'); ?>
<br><br><center><h2>Admin Login</h2><br>
<form action="proseslogin.php" method="post">
<center>USERNAME :<br><input type="text" name="username"><br></p></center>
<center>PASSWORD :<br><input type="password" name="password"><br></p></center>
<tr><td colspan="2" align="center"><input type="submit" value="Login"> <input type="reset" value="Batal"></td></tr>
</form>
</div>
<?php include ('../footer.php'); ?>