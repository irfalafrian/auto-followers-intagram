<?php
session_start();
if(!isset($_SESSION['username'])) {
header('location:login.php'); }
else { $username = $_SESSION['username']; }
require_once("../start.php");

include('html.inc'); 
include('container.inc');
include('menu.php');
echo "<div id=\"header\"><div id=\"wrap\">";
echo "<br/></center></div></div>";
echo "</center></div>";
include('../footer.php');
 ?>