<?php 
session_start();
if(!isset($_SESSION['username'])) {
header('location:login.php'); }
else { $username = $_SESSION['username']; }
require_once("../start.php");
require_once('../twitteroauth/twitteroauth.php');

include('html.inc'); 
if (!empty($_GET['message']) && $_GET['message'] == 'success') {
	echo '<div class="list"><center><h3>Berhasil meng-update data!</h3></div></center>';
}
?>
<div id="header"><div id="wrap">
<div class="listku">
<center><form name="formcari" method="post" action="hasil.php">
<table width="330" border="0" align="center" cellpadding="0">
<td height="25" colspan="3">
<strong> Cari Pengguna </strong>
</td>
</tr>
<tr> <td>  Username : </td>
<td> <input type="text" name="username"> </td>
</tr>
<td></td>
<td> <input type="SUBMIT" name="SUBMIT" id="SUBMIT" value="search" > </td>
</table>
<?php 
$BatasAwal = 50;
if (!empty($_GET['page'])) {
$hal = $_GET['page'] - 1;
$MulaiAwal = $BatasAwal * $hal;
} else if (!empty($_GET['page']) and $_GET['page'] == 1) {
$MulaiAwal = 0;
} else if (empty($_GET['page'])) {
$MulaiAwal = 0;
}//tampil data
$query = mysql_query("SELECT * FROM twitter_access_tokens LIMIT $MulaiAwal , $BatasAwal");
?><h2>Edit Pengguna</h2>
<table border="1" cellpadding="5" cellspacing="0">
	<thead>
    	<tr>
        	<td><b>No.</b></td>
        	<td><b>Username</b></td>
        	<td><b>Point</b></td>
			<td><b>Tingkat</b></td>
			<td><b>Opsi</b></td>
        </tr>
    </thead>
    <tbody>
    <?php 
	
	$no = 1;
	while ($data = mysql_fetch_array($query)) {
	?>
    	<tr>
        	<td><center><?php echo $no; ?></center></td>
        	<td><center><?php echo $data['username']; ?></center></td>
        	<td><center><?php echo $data['point']; ?></center></td>
            <td>
            	<center><a href="edit.php?id=<?php echo $data['id']; ?>">Edit</a></center>
            </td>
        </tr>
    <?php 
		$no++;
	} 
	?>
    </tbody>
</table><?php
$cekQuery = mysql_query("SELECT * FROM twitter_access_tokens");
$jumlahData = mysql_num_rows($cekQuery);
if ($jumlahData > $BatasAwal) {
echo '<br/><center><div style="font-size:10pt;">Page : ';
$a = explode(".", $jumlahData / $BatasAwal);
$b = $a[0];
$c = $b + 1;
for ($i = 1; $i <= $c; $i++) {
echo '<a style="text-decoration:none;';
if ($_GET['page'] == $i) {
echo 'color:red';
}
echo '" href="?page=' . $i . '">' . $i . '</a> > ';
}
echo '</div></center></div></div></div></center>';

include('../footer.php');
}
    	?>