<?php 
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar Modified by Josetstwn
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Twitter	: http://twitter.com/josetstwNakal
# Facebook	: http://www.facebook.com/josetstwn99
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
/* Memuat file yang dibutuhkan. */
session_start();
require_once('../twitteroauth/twitteroauth.php');
require_once('../start.php');


/* Mengambil akses token pengguna yang ada di sesi. */

$access_token = $_SESSION['access_token'];
/* Membuat objek TwitterOauth dengan konsumen / pengguna token. */
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);
/* Halaman yang ditampilkan ke pengguna. */
$ret = $connection->get('account/verify_credentials');
$name = $ret->screen_name;
$id = $ret->id;
$status = $ret->status;
$tweet = $status->text;
$idtweet = $status->id_str;
include('html.inc'); 
?>

<?php 
$id = $_GET['id'];

$query = mysql_query("select * from twitter_access_tokens where id='$id'") or die(mysql_error());

while($data = mysql_fetch_array($query)) {
?>

<div id="header"><div id="wrap">
<div class="listku"><form name="update_data" action="update.php" method="post">
<input type="hidden" name="id" value="<?php echo $id; ?>" />
<h2>Ubah Point <font color="red"><?php echo $data['username']; ?></font></h2>
<table border="0" cellpadding="5" cellspacing="0">
    <tbody>
    	<tr>
        	<td>Point</td>
        	<td>:</td>
        	<td><input type="text" name="point" maxlength="20" required="required" value="<?php echo $data['point']; ?>" /></td>
			  </tr>
        <tr>
        <tr>
        	<td align="right" colspan="3"><input type="submit" name="submit" value="Simpan" /></td>
        </tr>
    </tbody>
</table>
</form>

<a href="view.php">Lihat Data</a>
</div></div></div></body>
</html>
<?php } 
include ('../footer.php');
?>