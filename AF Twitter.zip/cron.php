<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
require_once('start.php');
$a = mysql_query("select * from twitter_access_tokens"); 
while($b = mysql_fetch_array($a))
{
$id = ($b['id']);
$time = date("i");
$q = mysql_query("select * from  twitter_access_tokens where id='$id' and minute='$time'");
if (mysql_num_rows($q) == 1) {
$point = "update twitter_access_tokens set minute = 0 where minute = $time";
$minute = "update twitter_access_tokens set point = 3 where point = 0";
$result = mysql_query($point);
$results = mysql_query($minute);
} 

else { 

echo "<br>";

}}

?>