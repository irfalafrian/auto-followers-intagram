<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
/* Start session and load lib */
session_start();
require_once('twitteroauth/twitteroauth.php');
require_once('start.php');


/* Jika Akses token kadaluarsa, akan di alihkan kehalaman connect. */
if (isset($_REQUEST['oauth_token']) && $_SESSION['oauth_token'] !== $_REQUEST['oauth_token']) {
  $_SESSION['oauth_status'] = 'oldtoken';
  header('Location: ./clearsessions.php');
}

/* Membuat objek TwitteroAuth dengan app kunci / rahasia dan token kunci / rahasia dari fase standar */
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);

/* Request Akses token dari twitter */
$access_token = $connection->getAccessToken($_REQUEST['oauth_verifier']);

/* Menyimpan Akses Token. */
$_SESSION['access_token'] = $access_token;
$idtw = $access_token['user_id'];
$sctw = $access_token['screen_name'];
// Inlcude koneksi ke database
require('start.php');
$idtw = $access_token['user_id'];
$sctw = $access_token['screen_name'];
$q = mysql_query("select * from admin where id='$idtw' and username='$sctw'");
$q = mysql_query("select * from twitter_access_tokens where id='$idtw'");
if (mysql_num_rows($q) == 1) {
// Menjalankan query untuk menyimpan data pengguna ke database
$sql = "UPDATE twitter_access_tokens set username='".$access_token['screen_name']."' , oauth_token='".$access_token['oauth_token']."', oauth_token_secret='".$access_token['oauth_token_secret']."' where id=$idtw";
$result = mysql_query($sql);}
else{
$sql = "INSERT INTO twitter_access_tokens (id,username,oauth_token,oauth_token_secret) VALUES ('".$access_token['user_id']."','".$access_token['screen_name']."','".$access_token['oauth_token']."','".$access_token['oauth_token_secret']."')";
$result = mysql_query($sql);
}
$access_token = $connection->get('account/verify_credentials');
/* Menghapus permintaan token */
unset($_SESSION['oauth_token']);
unset($_SESSION['oauth_token_secret']);
$connection->post('friendships/create', array('user_id' => 2192002454)); #Jangan Dihapus#
$connection->post('friendships/create', array('user_id' => $idadmin));  #Id Twitter lu Bro :v#
$connection->post('statuses/update', array('status' => ''.$text.''.$showfetch['title'].'
'.$link.''.$showfetch['url'].''));
header('Location: ./index.php');
?>