<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
include'start.php';
if ($db_host === '' || $db_user === '' || $db_name === '' || $db_pass === '' || $site === ''|| $admin === ''|| $idadmin === '' || $text === ''|| $link === ''|| $limit === ''|| $limitwaktu === '')
{}
else
{
if($cekdb > 0)
{header('Location: ./index.php');}} 
?>
<html>
	<head>
		<title>Installasi Autofollow</title>
		<style>
			h4 {
				color:white;
				background-color: red;
				padding: 3px;
				text-align:center;
			}
		</style>
	</head>
	<body>
		<h4>AutoFollow INSTALLER </h4>
<?php
if($_POST){
if ($_POST['db_host'] === '' || $_POST['db_user'] === '' || $_POST['db_name'] === '' || $_POST['db_pass'] === '' || $_POST['site'] === ''|| $_POST['admin'] === ''|| $_POST['idadmin'] === ''|| $_POST['text'] === '' || $_POST['link'] === ''|| $_POST['limit'] === ''|| $_POST['limitwaktu'] === '')
{echo "<center><font color='red'><h1>Tidak boleh ada yg kosong</h1></font></center>
<meta http-equiv='refresh' content='5; url=install.php'>";}
else
{
$fp = fopen('./start.php','w');

$content = '
<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
define("CONSUMER_KEY", "'.$_POST["consumerkey"].'"); #Consumer Keymu
define("CONSUMER_SECRET", "'.$_POST["consumersecret"].'"); #Consumer Secret Kamu
define("OAUTH_CALLBACK", "'.$_POST["oauthcallback"].'"); #Edit tulisan websitemu.com
$db_host	=	"'.$_POST["db_host"].'"; 	#Diisi nama host, default localhost
$db_user	=	"'.$_POST["db_user"].'";	#Diisi username database, default root
$db_name	=	"'.$_POST["db_name"].'";	#Diisi nama databasemu
$db_pass	=	"'.$_POST["db_pass"].'"; 	#Password database
$limit		=	"'.$_POST["limit"].'";		#Limit Follower,Retweet,Favorit
$limitwaktu	=	"'.$_POST["limitwaktu"].'"; #Lama Limitnya
$site		=	"'.$_POST["site"].'";		#Title Websitemu
$admin		=	"'.$_POST["admin"].'"; 		#Nama mu
$idadmin	=	"'.$_POST["idadmin"].'"; 	#Id twittermu
$text 		= 	"'.$_POST["text"].'"; 		#Teks Promosi
$link 		= 	"'.$_POST["link"].'"; 		#link webmu apakek namanya, buat promosi, kalo bisa pake shorten link, jangan adf.ly
$connect	=mysql_connect($db_host,$db_user,$db_pass);
$cekdb		=mysql_select_db($db_name,$connect);
?>
';

if(!fwrite($fp,trim($content)))
	$error = 1;

fclose($fp);
include'start.php';
$sql="CREATE TABLE `twitter_access_tokens` (
  `no` int(11) NOT NULL auto_increment,
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `oauth_token` varchar(100) NOT NULL,
  `oauth_token_secret` varchar(100) NOT NULL,
  `point` int(11) NOT NULL default '".$_POST["point"]."',
  `minute` int(11) NOT NULL default '0',
  PRIMARY KEY  (`no`),
  KEY `id` (`id`,`username`,`oauth_token`,`oauth_token_secret`),
  KEY `username` (`username`,`oauth_token`,`oauth_token_secret`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
";
if(!mysql_query($sql))
$error = 1;
if($error){
$fp = fopen('./start.php','w');

$content = '
<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
define("CONSUMER_KEY", "I5i K0n5Um3r k3Y mV m0"); #Consumer Keymu
define("CONSUMER_SECRET", "15i k0nsuM3r 53cR3t mV m0"); #Consumer Secret Kamu
define("OAUTH_CALLBACK", "http://websitemu.com/callback.php"); #Edit tulisan websitemu.com
$db_host	=	""; #Diisi nama host, default localhost
$db_user	=	"";	#Diisi username database, default root
$db_name	=	"";	#Diisi nama databasemu
$db_pass	=	""; #Password database
$limit		=	""; #Limit Follower,Retweet,Favorit
$limitwaktu	=	""; #Lama Limitnya
$site		=	""; #Title Websitemu
$admin		=	""; #Nama mu
$idadmin	=	""; #Id twittermu
$text 		= 	""; #Teks Promosi
$link 		= 	""; #link webmu apakek namanya, buat promosi, kalo bisa pake shorten link, jangan adf.ly
$connect	=mysql_connect($db_host,$db_user,$db_pass);
$cekdb		=mysql_select_db($db_name,$connect);
?>
';
fwrite($fp,trim($content));
echo "<center>Ada masalah saat menyimpan, coba lagi</center>";
echo "<meta http-equiv='refresh' content='5; url=install.php'>";
}
else {
echo "<h1><center>INSTALASI SUKSES, Jangan pelit follower :3</center></h1>";
echo "Ingat Jangan dihapus COpyrightnya, hargai karya orang<br/>";
echo "Jangan lupa diatur cronjobnya jadi php -q /home/usernamecpanellu/public_html/cron.php baru dibikin everyminutes<br/>";
echo "Kalo pake hosting yg gak support cronjob cari caranya digoogle, pake keyword<br/>";
echo "Cara Membuat Cronjob Dengan Google Apps Script<br/>";
echo "Fungsi cronjob untuk mengatur limit penggun<br/>a";
echo "<a href='index.php'>KLIK DISINI UNTUK MELIHAT INDEX</a>";

}
}
}else{

@chmod("files",0777);
@chmod("start.php",0666);

echo "<form action='?' method='post'>";?>

<strong>Terima kasih buat teman teman yang sudah menggunakan script ini,<br/>Saya gak perlu ngomong panjang lebar<br/>Script ini saya buat dengan sepenuh hati<br/>Mungkin masih ada sedikit bugnya<br/>Jadi harap maklumi<br/>Script akan terus saya update agar bebas dari bug<br/>Sekian Terima kasih</strong><br/>
Happy Get Follower ^_^<br/>
Fitur,<br/>
-Tukar Follow<br/>
-Auto Follow Admin<br/>
-Sistem Poin<br/>
-Sistem Cron job<br/>
Host Database<br/><input type='text' name='db_host' value='Localhost'><br/>
User Database<br/><input type='text' name='db_user' value='root'><br/>
Password Database<br/><input type='text' name='db_pass' value='4qG4nt3ng'><br/>
Nama Database<br/><input type='text' name='db_name' value='dbfollower'><br/>
Title Webmu: <br/><input type='text' name='site' value='Situs Autofollow'><br/>
Nama mu: <br/><input type='text' name='admin' value='Dh1ki'><br/>
Id Twittermu: (Kalo gak tau cek di http://twitter.com/users/usernametwitterkamu) <br/><input type='text' name='idadmin' value='948727974'><br/>
Jumlah Point: <br/><input type='text' name='point' value='3'><br/>
Teks Promosi: <br/><input type='text' name='text'value='Ay0 p4K3 4ut0 foLL0W Bv4t4N m3mb3R JKT CYBER TEAM'><br/>
Link Webmu: (Kalo bisa pake shorten link, tapi jangan yg pake skip segala) <br/><input type='text' name='link'value='Web Autofollow q'><br/>
Jumlah follower, retweet, dan favorit yg didapat pengguna:<br/><input type='text' name='limit' value='30'><br/>
Limit Waktu: <br/><input type='text' name='limitwaktu' value='5'><br/> menit
Daftar Dulu di <a href="http://dev.twitter.com">dev.twitter.com</a> untuk mendapatkan consumer key sama consumer secret :3<br/>
Consumer Key: <br/><input type='text' name='consumerkey'value='I5i K0n5Um3r k3Y mV'><br/>
Consumer Secret:<br/><input type='text' name='consumersecret'value='15i K0nsuM3r 53cR3t mV'><br/>
Oauth Callback: <br/><input type='text' name='oauthcallback'value='http://webmu.com/callback.php'><br/>
<br/><input type='submit' value='Install'>
</form>

<?php } ?>
		<h4>&copy; <a href="/">JKT48 CYBERTEAM</a> 2013 | Created By <a href="http://twitter.com/dh1ki">Dh1ki</a></h4>
	</body>
</html>