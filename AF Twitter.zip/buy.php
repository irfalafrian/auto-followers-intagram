<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
require_once('start.php');
include('html2.inc');  
?>
<div class="listku">
<h2>Harga Point</h2>
<h3><font color ="red">50 = Rp 5000 (Pulsa)</font><br/>
<font color ="black">150 = Rp 10000 (Pulsa)</font>
<font color ="black">250 = Rp 10000 (Bank)</font><br/>
<font color ="green">400 = Rp 20000 (Pulsa)</font>
<font color ="green">650 = Rp 20000 (Bank)</font><br/>
Pesan bisa Via Twitter atau Sms<br/>
</h3>
<br /></div>
<?php include('footer.php');?>