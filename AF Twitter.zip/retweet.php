<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
if ($db_host === '' || $db_user === '' || $db_name === '' || $db_pass === '' || $site === ''|| $admin === ''|| $idadmin === '' || $text === ''|| $link === ''|| $limit === ''|| $limitwaktu === '')
{echo "<meta http-equiv='refresh' content='0; url=install.php'>";}
/* Memuat file yang dibutuhkan. */
session_start();
require_once('twitteroauth/twitteroauth.php');
require_once('start.php');

/* Jika Akses token kadaluarsa, akan di alihkan kehalaman connect. */
if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
    header('Location: ./clearsessions.php');
}
/* Mengambil akses token pengguna yang ada di sesi. */
$access_token = $_SESSION['access_token'];

/* Membuat objek TwitterOauth dengan konsumen / pengguna token. */
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

/* Halaman yang ditampilkan ke pengguna. */
$ret = $connection->get('account/verify_credentials');
$name = $ret->name;
$status = $ret->status;
$tweet = $status->text;
$idtweet = $status->id_str;
$fol = $connection->get('account/verify_credentials');
$name = $fol->name;
$id = $fol->id;
$follower = $fol->followers_count;
$ret = $connection->get('account/verify_credentials');
$name = $ret->name;
$status = $ret->status;
$tweet = $status->text;
$idtweet = $status->id_str;
include('html.inc');
$query = mysql_query("SELECT * FROM twitter_access_tokens WHERE id='$id'");
$point = mysql_result($query,0, "point");
if (!empty($_GET['get']) && $_GET['get'] == 'sukses') {
echo '<div class="list"><center><font size="+1"><h3>BERHASIL MENDAPATKAN RETWEET!</h3></font></center></div>';
}
echo "<div class=\"listku\"><center>Hallo <b>".$name."</b><h2>Sisa Pointmu : $point</h2>
Tweet Terakhirmu<br/><font color=\"red\">".$tweet."</font> <br/><p><form action=\"submitret.php\" method=\"POST\"><input type=\"text\" name =\"retweet\" value=\"".$idtweet."\" /></p><input class=\"button\" value=\"Dapatkan Retweet\"  type=\"submit\" /></form><br/>";
echo "</center></div>";
echo"</div>";
include('footer.php');
echo "<noscript>";
?>