<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
if ($db_host === '' || $db_user === '' || $db_name === '' || $db_pass === '' || $site === ''|| $admin === ''|| $idadmin === '' || $text === ''|| $link === ''|| $limit === ''|| $limitwaktu === '')
{echo "<meta http-equiv='refresh' content='0; url=install.php'>";}
require_once('start.php');
include('html2.inc');
if (CONSUMER_KEY === '' || CONSUMER_SECRET === '') {
  echo 'WEBSITE IS MAINTENANCE';
  exit;
  
}


/* Build an image link to start the redirect process. */
echo "<div class=\"listku\"><center><b>Dapatkan $limit follower setiap $limitwaktu menit<br/>Cukup klik</b><br/><br/><a href=\"./redirect.php\"><img src=\"./images/darker.png\" alt=\"Sign in with Twitter\"/></a><br/><b><font color='red'>KAMI TIDAK PERNAH MEMINTA PASSWORD ANDA</font></b></center></div>";
echo "<hr />";
echo "<div class=\"listku\"><center>Jumlah Member Saat Ini</br>";
$result = mysql_query("SELECT * FROM twitter_access_tokens");
$num_rows = mysql_num_rows($result);
{
echo "<b><font size=\"+1\"color=\"red\">".$num_rows."</font> orang</b>";
}
 echo "</center></div>";

/* Include HTML to display on the page. */
print_r($access_token);
include('footer.php');