<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
require_once('start.php');
include('html2.inc');  
?>
<div class="listku">
<h2>Peraturan</h2>
Jangan menggUNFOLLOW sesama pengguna aplikasi <?php echo' <b>'.$site.'</b>'; ?>.<br/>
Jangan menggunakan Aplikasi <?php echo' <b>'.$site.'</b>'; ?> untuk tindakan SARA, Porno, dan Menghina.</h2><br/><br/>
<font color="green">Apakah ini aman?</font><br />
Tentu saja aman karena kami menggunakan <a href="https://dev.twitter.com/docs/api/1.1" rel="nofollow" target="_blank">API TWITTER</a>&nbsp;,Kami juga tidak menyimpan password anda<br />
<br />
<font color="green">Kenapa akun twitter saya otomatis Ngefollow, Ngeretweet dan Ngetweet?</font><br />
1.Akun anda Ngefollow otomatis karena memang ini sistem tukar follow <font color="red">(anda mendapatkan followers tapi anda juga harus follow orang)</font><br />
2.Akun anda Ngeretweet otomatis karena memang ini sistem tukar retweet juga <font color="red">(anda mendapatkan retweet tapi anda juga harus retweet orang)</font><br />
2.Akun anda ngetweet otomatis karena kami menggunakan fitur ini untuk promo <font color="red">(promo juga tujuan buat nambah member <?php echo' <b>'.$site.'</b>'; ?> biar followers kalian naik terus)</font><br />
<br />
<font color="green">Kenapa setelah menggunakan <?php echo' <b>'.$site.'</b>'; ?> akun saya langsung disuspend?</font><br />
1.Anda terlalu sering menggunakan <?php echo' <b>'.$site.'</b>'; ?> <font color="red">(Secara Tidak Wajar)</font><br />
2.Twitter ngeblokir URL <?php echo' <b>'.$site.'</b>'; ?> sehingga ketika anda ngetweet yang ada URL <?php echo' <b>'.$site.'</b>'; ?>nya maka secara otomatis akun anda akan <font color="red">&nbsp;disuspend</font><br />
3.Akun baru/Akun Fake<br />
<br />
<font color="green">Saya ingin berhenti dari <?php echo' <b>'.$site.'</b>'; ?> bagimana caraya?</font><br />
Anda pergi ke <a href="http://twitter.com/settings/applications" rel="nofollow" target="_blank">http://twitter.com/settings/applications</a> lalu hapus semua aplikasi yang ada disana<br />
<br />
<font color="green">Cara buka akun yang disuspend bagimana caranya?</font><br />
Untuk ini coba ke support.twitter.com/articles/20169350-akun-saya-ditangguhkan<br />
<br /></div>
<?php include('footer.php');?>