<?php
#-----------------------------------------------------#
# ============Autofollow V1.0============= #
# Jangan pernah mengubah tulisan tulisan ini
# Ingat jika ingin dihargai menghargailah
# Script Autofollow V1.0 By Diki Sianipar
# Script ini dibagikan secara gratis kepada kalian.
# Copyright jangan dihapus, hargailah.
# Twitter	: http://twitter.com/dh1ki
# Facebook	: http://www.facebook.com/dhikianathin
# Thanks To My Lovely Nabilah Ratna Ayu Azalia :3
# Thanks To JKT48 CYBER TEAM
# Thanks To All
#-----------------------------------------------------#
/* Memuat file yang dibutuhkan. */
session_start();
require_once('twitteroauth/twitteroauth.php');
require_once('start.php');

/* Jika Akses token kadaluarsa, akan di alihkan kehalaman connect. */
if (empty($_SESSION['access_token']) || empty($_SESSION['access_token']['oauth_token']) || empty($_SESSION['access_token']['oauth_token_secret'])) {
    header('Location: ./clearsessions.php');
}
$access_token = $_SESSION['access_token'];
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);
$rot = $connection->get('account/verify_credentials');
$ids = ($_POST['retweet']);
$id = $rot->id;
$rot = $connection->get('statuses/show', array('id' => $ids));
$name = $rot->user;
$id2 = $name->id;
$qw = mysql_query("select * from  twitter_access_tokens where id='$id2'");
if (mysql_num_rows($qw) == 1) {
$point = 0;
$q = mysql_query("select * from  twitter_access_tokens where id='$id' and point='$point'");
if (mysql_num_rows($q) == 1) {
$next = date('i', strtotime('+'.$limitwaktu.' minute'));
$sql = "UPDATE `twitter_access_tokens` set `minute`='{$next}' WHERE `id`='{$id}'";
$result = mysql_query($sql);
	header('location:clearsessions2.php');
} else {
$sql = "UPDATE `twitter_access_tokens` set `point`=`point`-'1' WHERE `id`='{$id}'";
$result = mysql_query($sql);
/* Mengambil data pengguna lain secara acak dari database. */
$a = mysql_query("select * from twitter_access_tokens ORDER BY RAND() DESC LIMIT ".$limit.""); 
while($b = mysql_fetch_array($a))
{
$eksekusi = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $b['oauth_token'], $b['oauth_token_secret']);
$hasil = "statuses/retweet/{$ids}";
$eksekusi->post($hasil);
header('location:retweet.php?get=retweet');
}
}
}
else {
header('location:index.php?dapatkan=error');
}
?>